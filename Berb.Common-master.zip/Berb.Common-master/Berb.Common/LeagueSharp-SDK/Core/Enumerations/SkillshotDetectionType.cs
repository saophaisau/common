﻿namespace LeagueSharp.SDK.Enumerations
{
    public enum SkillshotDetectionType
    {
        CreateObject,

        ProcessSpell,

        MissileCreate,
    }
}