﻿namespace LeagueSharp.SDK
{
    public enum SkillshotDetectionType
    {
        CreateObject,

        ProcessSpell,

        MissileCreate,
    }
}